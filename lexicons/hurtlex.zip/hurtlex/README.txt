HurtLex is distributed as a series of tab-separated text files.
For each of the 53 languages, two files are provided:
- hurtlex_XX_restricted: obtained by translating offensive senses of the
words in the original lexicon.
- hurtlex_XX_inclusive: obtained by translating all the potentially relevant
senses of the words in the original lexicon.

The columns, represent, in order, the word category, the stereotype
macro-category (yes/no) and the lemma.
The 14 categories are:

PS:  Negative stereotypes ethnic slurs
RCI: locations and demonyms
PA:  professions and occupations 
DDF: physical disabilities and diversity
DDP  cognitive disabilities and diversity
DMC: moral and behavioral defects
IS:  words related to social and economic disadvantage
OR:  plants
AN:  animals 
ASM: male genitalia
ASF: female genitalia
PR:  words related to prostitution
OM:  words related to homosexuality
QAS: with potential negative connotations
CDS: derogatory words
RE:  felonies and words related to crime and immoral behavior
SVP: words related to the seven deadly sins of the Christian tradition

Details are in the paper:

Elisa Bassignana, Valerio Basile, Viviana Patti. 
Hurtlex: A Multilingual Lexicon of Words to Hurt. 
In Proceedings of the Fifth Italian Conference on Computational 
Linguistics (CLiC-It 2018)
http://ceur-ws.org/Vol-2253/paper49.pdf
